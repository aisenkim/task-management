/**
 * Creating as interface because it will be used in multiple places
 */
export interface JwtPayload {
  username: string;
}
